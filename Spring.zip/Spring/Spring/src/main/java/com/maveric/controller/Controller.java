package com.maveric.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.maveric.model.LoginService;
import com.maveric.model.Loginmodel;
import com.maveric.model.Online;
import com.maveric.model.Productmodel;
import com.maveric.model.RegisterService;

@Controller

public class Controller {

	@Autowired
	RegisterService is;
	@Autowired
    LoginService ls;
	
    
	@RequestMapping(value="/")
	public String maveric(Model model)

	{
		System.out.println("Entered into index page");
		model.addAttribute("Online", new Online());
		return "Register";
	}

	@RequestMapping(value = "/Register", method=RequestMethod.POST)

	public String test(@ModelAttribute("Online") Online Online) 
	{
		String s = is.value(Online);
		System.out.println("Entered in design page");
		return "Login";

		
	}
	
	@RequestMapping(value = "/Login", method=RequestMethod.POST)

	public String test1(@ModelAttribute("Loginmodel") Loginmodel LM, Model model) 
	{
		String s = ls.value(LM);
		System.out.println("Entered into design page");
		model.addAttribute("Productmodel", new Productmodel());
		return "Product";
	
	}
	
	@RequestMapping(value = "/dispProdDetails", method=RequestMethod.POST)

	public String productlist(Model model, Productmodel productmodel) 
	{
		List<Productmodel> productList = ls.productlist(productmodel.getProductselect());
		System.out.println("Product list is displayed");
		model.addAttribute("Productmodel", new Productmodel());
		model.addAttribute("productList", productList);
		return "Product";
	
	}
}
