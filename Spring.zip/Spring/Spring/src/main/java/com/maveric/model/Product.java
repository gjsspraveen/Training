package com.maveric.model;

public class Product 
{
	private String productid;
	private String productname;
	private String description;
	private String startdate;
	private String expirydate;
	private String productselect;
	private String productCart;
	
	public String getProductCart() {
		return productCart;
	}
	public void setProductCart(String productCart) {
		this.productCart = productCart;
	}
	public String getProductselect() {
		return productselect;
	}
	public void setProductselect(String productselect) {
		this.productselect = productselect;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}
	
}
