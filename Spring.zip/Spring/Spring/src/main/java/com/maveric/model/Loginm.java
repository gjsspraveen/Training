package com.maveric.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.dao.Dao;

@Service

public class Loginm 
{

	@Autowired	
	Dao ud;
	
	public String value(Login user)
	{
		String s=null;
		int i=ud.checkLogin(user);
		
		
		if(i>0)
		{
			System.out.println("Successfully Login");
			s="Product";
		}
		else
		{
			System.out.println("Not successfully login");
			s="Login";
		}
		return s;
		
     }
	
	public List<Productmodel> productlist(String productselect)
	{
		List<Productmodel> Lit = new ArrayList<Productmodel>();
		try 
		{
			Lit = ud.productByList(productselect);
		} 
		catch (Exception e)
		{
			// TODO: handle exception
		}
		
		
		return Lit;
		
     }

	
	
}
