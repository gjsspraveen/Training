package com.maveric.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.maveric.model.LoginService;
import com.maveric.model.Loginmodel;
import com.maveric.model.Online;
import com.maveric.model.Productmodel;
@Repository
public class Dao 
{
	 static final String JDBC_DRIVER ="com.mysql.cj.jdbc.Driver";
	  static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/sruthi";
	  
	  static final String USER = "root";
	  static final String PASS = "";
	  
	  static  Connection conn = null;
	  static  Statement stmt = null;
	  
@Autowired
private JdbcTemplate jdbcTemplate; 

	public int test(Online Online)
	{
	  int i=0;
	  System.out.println(Online.getConfirmPassword());
	  String query="INSERT INTO  newmaven values(?,?, ?, ?)";
	  
	  i=jdbcTemplate.update(query,Online.getUser(),Online.getPass(),Online.getConfirmPassword(),Online.getEmail());
	  
	  return i;
	}
	
	public int checkLogin(Loginmodel regModel) {
		String sql = " SELECT * FROM newmaven WHERE UserName = '"+ regModel.getUserName()+"' and Password = '"+ regModel.getPassword()+"' ";
		return jdbcTemplate.query(sql, new ResultSetExtractor<Integer>() 
		{

		public Integer extractData(ResultSet rs) throws SQLException, DataAccessException 
		{
		int result = 0;
		if (rs.next())
		{
		result = 1;
		}
		else 
		{
		 result = 0;
		}
		
		return result;
		}

		});
	}
	
	public List<Productmodel> productByList(String productselect) {
		List<Productmodel> productList = new ArrayList<Productmodel>();
		try {
		String query = "select * from productlist where productid = '"+productselect+"'";
		productList = (List<Productmodel>) jdbcTemplate.query(query, new BeanPropertyRowMapper(Productmodel.class));
		} catch (Exception e) {
		productList = new ArrayList<Productmodel>();
		System.out.println(e.getMessage());
		}
		return productList;
	}
	


}