package com.maveric.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.maveric.dao.Dao;

@Service

 public class RegisterSer
  {
		@Autowired
		Dao ud;
		
		public String value(Online user)
		{
			String str=null;
			int i=ud.test(user);
			
			
			if(i>0)
			{
				System.out.println("Inserted into DB");
				str="Design";
			}
			else
			{
				System.out.println("Not Inserted into DB");
			}
			return str;
		}	
  }
